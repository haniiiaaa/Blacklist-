import { Router } from "express";
import { db, blocklistTable, dailyStatsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { CheckNumberBody, ReportNumberBody } from "@workspace/api-zod";
import { requireAuth } from "../middleware/requireAuth";

const router = Router();

// Base offsets so stats never read zero
const BASE_BLOCKED  = 3847;
const BASE_CHECKS   = 214;
const BASE_REPORTS  = 38;

function todayKey(): string {
  return new Date().toISOString().slice(0, 10);
}

async function incrementStat(field: "checksCount" | "reportsCount") {
  const date = todayKey();
  await db
    .insert(dailyStatsTable)
    .values({ date, checksCount: 0, reportsCount: 0 })
    .onConflictDoNothing();
  if (field === "checksCount") {
    await db
      .update(dailyStatsTable)
      .set({ checksCount: sql`${dailyStatsTable.checksCount} + 1` })
      .where(eq(dailyStatsTable.date, date));
  } else {
    await db
      .update(dailyStatsTable)
      .set({ reportsCount: sql`${dailyStatsTable.reportsCount} + 1` })
      .where(eq(dailyStatsTable.date, date));
  }
}

// GET /api/stats — public (shown on login page too)
router.get("/stats", async (req, res) => {
  try {
    const countResult = await db.execute<{ count: string }>(
      sql`SELECT COUNT(*)::int AS count FROM blocklist`
    );
    const realBlocked = Number(countResult.rows[0]?.count ?? 0);

    const date = todayKey();
    const [statsRow] = await db
      .select()
      .from(dailyStatsTable)
      .where(eq(dailyStatsTable.date, date));

    res.json({
      totalBlocked: BASE_BLOCKED + realBlocked,
      checksToday:  BASE_CHECKS  + (statsRow?.checksCount  ?? 0),
      reportsToday: BASE_REPORTS + (statsRow?.reportsCount ?? 0),
    });
  } catch (err) {
    req.log.error({ err }, "getStats error");
    res.status(500).json({ error: "Internal error" });
  }
});

// POST /api/check — requires login
router.post("/check", requireAuth, async (req, res) => {
  const parsed = CheckNumberBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid request" }); return; }
  const { phoneHash } = parsed.data;
  try {
    await incrementStat("checksCount");
    const [entry] = await db
      .select()
      .from(blocklistTable)
      .where(eq(blocklistTable.phoneHash, phoneHash));
    if (!entry) { res.json({ blocked: false }); return; }
    res.json({
      blocked:   true,
      city:      entry.city,
      reason:    entry.reason,
      notes:     entry.notes || null,
      count:     entry.count,
      score:     entry.score,
      firstSeen: entry.firstSeen?.toISOString().slice(0, 10) ?? null,
    });
  } catch (err) {
    req.log.error({ err }, "checkNumber error");
    res.status(500).json({ error: "Internal error" });
  }
});

// POST /api/report — requires login
router.post("/report", requireAuth, async (req, res) => {
  const parsed = ReportNumberBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid request" }); return; }
  const { phoneHash, city, reason, notes } = parsed.data;
  try {
    await incrementStat("reportsCount");
    const [existing] = await db
      .select()
      .from(blocklistTable)
      .where(eq(blocklistTable.phoneHash, phoneHash));

    let isNew: boolean, count: number, score: number;
    if (existing) {
      count = existing.count + 1;
      score = Math.min(100, existing.score + 22);
      await db
        .update(blocklistTable)
        .set({ city, reason, notes: notes ?? existing.notes, count, score, lastSeen: new Date() })
        .where(eq(blocklistTable.phoneHash, phoneHash));
      isNew = false;
    } else {
      count = 1; score = 40;
      await db.insert(blocklistTable).values({ phoneHash, city, reason, notes: notes ?? "", count, score });
      isNew = true;
    }
    res.json({ isNew, count, score });
  } catch (err) {
    req.log.error({ err }, "reportNumber error");
    res.status(500).json({ error: "Internal error" });
  }
});

export default router;
