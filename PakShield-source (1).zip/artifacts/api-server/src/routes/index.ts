import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import blocklistRouter from "./blocklist";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(blocklistRouter);

export default router;
