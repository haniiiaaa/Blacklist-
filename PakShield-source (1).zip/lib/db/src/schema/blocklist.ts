import { pgTable, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const blocklistTable = pgTable("blocklist", {
  phoneHash:  text("phone_hash").primaryKey(),
  city:       text("city").notNull(),
  reason:     text("reason").notNull(),
  notes:      text("notes").notNull().default(""),
  count:      integer("count").notNull().default(1),
  score:      integer("score").notNull().default(40),
  firstSeen:  timestamp("first_seen").notNull().defaultNow(),
  lastSeen:   timestamp("last_seen").notNull().defaultNow(),
});

export const insertBlocklistSchema = createInsertSchema(blocklistTable).omit({
  firstSeen: true,
  lastSeen: true,
});

export type InsertBlocklist = z.infer<typeof insertBlocklistSchema>;
export type Blocklist = typeof blocklistTable.$inferSelect;

export const dailyStatsTable = pgTable("daily_stats", {
  date:          text("date").primaryKey(),
  checksCount:   integer("checks_count").notNull().default(0),
  reportsCount:  integer("reports_count").notNull().default(0),
});
